
# Eve Cloud Back Office

## Designed For:
- Cloud platforms like Render, Railway, Heroku, Fly.io, etc.
- Runs 24/7 with zero user input after deployment.

## Instructions:
1. Upload these files to your cloud IDE.
2. Set Python version to 3.9 or 3.10.
3. Add auto-start script: `python main.py`
4. Optional: Connect SMTP/Zapier webhook for outbound communication.

## Result:
Eve runs in the cloud and manages job search + empire ops.
